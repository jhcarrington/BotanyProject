//
//  DirtViewController.swift
//  Botany
//
//  Created by Jason Carrington on 2/23/19.
//  Copyright © 2019 Jason Carrington. All rights reserved.
//

import UIKit


class IntroViewController: UIViewController {
    @IBOutlet weak var outline: UIView!
    
    @IBOutlet weak var First: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        outline.layer.cornerRadius = 20
        if let rtfPath = Bundle.main.url(forResource: "first", withExtension: "rtf") {
            do {
                let attributedStringWithRtf: NSAttributedString = try NSAttributedString(url: rtfPath, options: [NSAttributedString.DocumentReadingOptionKey.documentType: NSAttributedString.DocumentType.rtf], documentAttributes: nil)
                First.attributedText = attributedStringWithRtf
            } catch let error {
                print("Got an error \(error)")
            }
        }
//        let url = Bundle.main.url(forResource: "first", withExtension: "rtf")
//        do {
//            let data = try Data(contentsOf:url!)
//            let attibutedString = try NSAttributedString(data: data, documentAttributes: nil)
//            let fullText = attibutedString.string
//            First.text = fullText
//
//        } catch {
//            print(error)
//        }
    
        
    }
    @IBAction func backButton(_ sender: Any) {
        navigationController?.popViewController(animated: true)
}

}
