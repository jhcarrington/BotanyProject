//
//  DirtViewController.swift
//  Botany
//
//  Created by Jason Carrington on 2/23/19.
//  Copyright © 2019 Jason Carrington. All rights reserved.
//

import UIKit


class IntroViewController: UIViewController {
    @IBOutlet weak var outline: UIView!
    
    @IBOutlet weak var First: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        outline.layer.cornerRadius = 20
        let url = Bundle.main.url(forResource: "first", withExtension: "rtf")
        do {
            let data = try Data(contentsOf:url!)
            let attibutedString = try NSAttributedString(data: data, documentAttributes: nil)
            let fullText = attibutedString.string
            First.text = fullText
            
        } catch {
            print(error)
        }
    
        
    }
    @IBAction func backButton(_ sender: Any) {
        navigationController?.popViewController(animated: true)
}

}
