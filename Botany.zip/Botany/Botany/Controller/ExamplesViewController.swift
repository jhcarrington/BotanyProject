//
//  ViewController.swift
//  Botany
//
//  Created by user148911 on 2/23/19.
//  Copyright © 2019 Jason Carrington. All rights reserved.
//

import UIKit

class ExamplesViewController: UIViewController {
    @IBOutlet weak var outline: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        outline.layer.cornerRadius = 20
    }
    @IBAction func backButton(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }



}

