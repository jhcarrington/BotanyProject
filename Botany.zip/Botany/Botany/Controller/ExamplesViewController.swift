//
//  ViewController.swift
//  Botany
//
//  Created by user148911 on 2/23/19.
//  Copyright © 2019 Jason Carrington. All rights reserved.
//

import UIKit

class ExamplesViewController: UIViewController {
    @IBOutlet weak var outline: UIView!
    
    @IBOutlet weak var last: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        outline.layer.cornerRadius = 20
        let myMutableString = NSMutableAttributedString(string: "Compared to grazing exclusion, mowing marginally promoted soil carbon stock. This result can be explained by suppressed soil respiration, because mowing can reduce soil labile carbon and affect microbial community structure.\n\n*Soil respiration is the CO2 produced by the biological activity of soil organisms, including plant roots, microbes, and soil animals\n\nHowever, mowing can cause a reduction in litter cover and an increase in bare ground, which increases water loss by runoff and soil evaporation.", attributes: nil)
        myMutableString.addAttribute(NSAttributedString.Key.foregroundColor, value: UIColor.blue, range: NSRange(location:120,length:16))
        // set label Attribute
        last.attributedText = myMutableString
    }
    @IBAction func backButton(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }

    @IBAction func forwardButton(_ sender: Any) {
        let viewController:UIViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "examples2") as UIViewController
        self.show(viewController, sender: (Any).self)
    }
    

}

