//
//  SandViewController.swift
//  Botany
//
//  Created by Jason Carrington on 2/23/19.
//  Copyright © 2019 Jason Carrington. All rights reserved.
//

import UIKit


class SoilManagementViewController: UIViewController {
    @IBOutlet weak var outline: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        outline.layer.cornerRadius = 20
        
    }
    @IBAction func backButton(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
}

