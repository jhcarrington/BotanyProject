//
//  MenuViewController.swift
//  Botany
//
//  Created by Jason Carrington on 2/23/19.
//  Copyright © 2019 Jason Carrington. All rights reserved.
//

import UIKit

class MenuViewController: UIViewController {
    @IBOutlet weak var outline: UIView!
    @IBOutlet weak var sandButton: UIButton!
    @IBOutlet weak var dirtButton: UIButton!
    
    @IBOutlet weak var soilButton2: UIButton!
    @IBOutlet weak var soilButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        outline.layer.cornerRadius = 20
    }
    @IBAction func buttonDownAnimate(_ sender: UIButton) {
        UIButton.animate(withDuration: 0.2, animations: {sender.transform = CGAffineTransform(scaleX: 0.8, y: 0.8)
        }, completion: { finish in
            UIButton.animate(withDuration: 0.2, animations: {
                sender.transform = CGAffineTransform.identity
            })
        })
    }
    @IBAction func sandButtonPress(_ sender: Any) {
//        sandButton.layer.shadowOffset = CGSize(width: 5, height: 5)
        let viewController:UIViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SandView") as UIViewController
        self.show(viewController, sender: (Any).self)
    }
    
    @IBAction func soildButton2Press(_ sender: Any) {
//        soilButton.layer.shadowOffset = CGSize(width: 5, height: 5)
    }
    @IBAction func soilButtonPress(_ sender: Any) {
//        soilButton2.layer.shadowOffset = CGSize(width: 5, height: 5)
    }
    @IBAction func upOutside(_ sender: UIButton) {
//        sender.layer.shadowOffset = CGSize(width: 5, height: 5)
    }
    
    @IBAction func dirtButtonPress(_ sender: Any) {
//        dirtButton.layer.shadowOffset = CGSize(width: 5, height: 5)
        let viewController:UIViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "DirtView") as UIViewController
        self.show(viewController, sender: (Any).self)
    }
}
