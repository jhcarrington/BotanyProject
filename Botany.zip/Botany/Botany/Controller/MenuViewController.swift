//
//  MenuViewController.swift
//  Botany
//
//  Created by Jason Carrington on 2/23/19.
//  Copyright © 2019 Jason Carrington. All rights reserved.
//

import UIKit

class MenuViewController: UIViewController {
    @IBOutlet weak var outline: UIView!
    @IBOutlet weak var sandButton: UIButton!
    @IBOutlet weak var dirtButton: UIButton!
    
    @IBOutlet weak var soilButton2: UIButton!
    @IBOutlet weak var soilButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        outline.layer.cornerRadius = 20
        sandButton.layer.cornerRadius = 20
        dirtButton.layer.cornerRadius = 20
        soilButton.layer.cornerRadius = 20
        soilButton2.layer.cornerRadius = 20
        sandButton.layer.shadowOffset = CGSize(width: 5, height: 5)
        sandButton.layer.shadowColor = UIColor.gray.cgColor
        sandButton.layer.shadowOpacity = 1
        dirtButton.layer.shadowOffset = CGSize(width: 5, height: 5)
        dirtButton.layer.shadowColor = UIColor.gray.cgColor
        dirtButton.layer.shadowOpacity = 1
        soilButton.layer.shadowOffset = CGSize(width: 5, height: 5)
        soilButton.layer.shadowColor = UIColor.gray.cgColor
        soilButton.layer.shadowOpacity = 1
        soilButton2.layer.shadowOffset = CGSize(width: 5, height: 5)
        soilButton2.layer.shadowColor = UIColor.gray.cgColor
        soilButton2.layer.shadowOpacity = 1
    }
    @IBAction func buttonDownAnimate(_ sender: UIButton) {
        sender.layer.shadowOffset = CGSize(width: 0, height: 0)
    }
    @IBAction func sandButtonPress(_ sender: Any) {
        sandButton.layer.shadowOffset = CGSize(width: 5, height: 5)
        let viewController:UIViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SandView") as UIViewController
        
        self.show(viewController, sender: (Any).self)
    }
    
    @IBAction func soildButton2Press(_ sender: Any) {
        soilButton.layer.shadowOffset = CGSize(width: 5, height: 5)
    }
    @IBAction func soilButtonPress(_ sender: Any) {
        soilButton2.layer.shadowOffset = CGSize(width: 5, height: 5)
    }
    @IBAction func upOutside(_ sender: UIButton) {
        sender.layer.shadowOffset = CGSize(width: 5, height: 5)
    }
    
    @IBAction func dirtButtonPress(_ sender: Any) {
        dirtButton.layer.shadowOffset = CGSize(width: 5, height: 5)
    }
}
