//
//  MenuViewController.swift
//  Botany
//
//  Created by Jason Carrington on 2/23/19.
//  Copyright © 2019 Jason Carrington. All rights reserved.
//

import UIKit

class MenuViewController: UIViewController {
    @IBOutlet weak var outline: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        outline.layer.cornerRadius = 20
    }
    @IBAction func buttonDownAnimate(_ sender: UIButton) {
        UIButton.animate(withDuration: 0.2, animations: {sender.transform = CGAffineTransform(scaleX: 0.8, y: 0.8)
        }, completion: { finish in
            UIButton.animate(withDuration: 0.2, animations: {
                sender.transform = CGAffineTransform.identity
            })
        })
    }
    @IBAction func introButtonPress(_ sender: Any) {
        let viewController:UIViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "intro") as UIViewController
        self.show(viewController, sender: (Any).self)
    }
    
    @IBAction func soilManButtonPress(_ sender: Any) {
        let viewController:UIViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "soilMan") as UIViewController
        self.show(viewController, sender: (Any).self)
    }
    @IBAction func examplesManButtonPress(_ sender: Any) {
        let viewController:UIViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "examples") as UIViewController
        self.show(viewController, sender: (Any).self)
    }
}
